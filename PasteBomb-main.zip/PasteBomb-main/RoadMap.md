0.01 (Pre-Alpha) <--- Current Version
- Launch

0.011 (Pre-Alpha)
- Fully implement Discord WebHook system on `main` branch

0.012-0.019 (Pre-Alpha)
- Bug fixes and general improvements 

0.2 (Alpha)
- New Commands and Better Stealth 

0.21 (Alpha)
- Bug Fixes

0.3 (Alpha)
- Attacker Side CLI

0.31 (Alpha)
- CLI Bug Fixes

0.32 (Alpha)
- CLI Quality of Life Improvements

0.4 (Alpha)
- New Commands and Even Better Stealth 

0.41 (Alpha)
- Bug Fixes

0.5 (Beta)
- C++ Version
- C Version

0.6 (Beta)
- Proxy System allowing the attacker to use any of the victim devices and proxy servers

0.61 (Beta)
- Proxy bug fixes and general quality of life improvements

0.7 (Beta)
- Even More Commands 

0.8 (Beta)
- Support for PasteBin services hosted on TOR hidden services

0.9 (Beta)
- Attacker Side GUI

0.91 (Beta)
- GUI Bug Fixes

0.92 (Beta)
- GUI Quality of Life Improvements

1.0 (Full Release)
- More Commands
- Better Stealth
- Mobile Version (Android)
- Assembly Version (x86, x86-64, ARM)
